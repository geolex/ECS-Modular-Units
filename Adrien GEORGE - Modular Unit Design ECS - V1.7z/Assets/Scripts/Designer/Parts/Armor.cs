﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Armor : Part
{
    public int m_armor;
    public int m_life;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
