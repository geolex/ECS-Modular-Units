﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Part : MonoBehaviour
{
    // All the Slots in the Part
    [SerializeField] private List<Slot> m_slots;

    [SerializeField] private Mesh m_mesh;
    [SerializeField] private Material m_material;

    // Part Characteristics
    public PartType m_type;
    public PartSize m_size;

    public Mesh Mesh { get => m_mesh; set => m_mesh = value; }


    // Will return all the direct childs of a part
    public List<Part> GetChilds<T>()
    {
        List<Part> childs = new List<Part>();

        m_slots.ForEach(slot =>
        {
            Part part = slot.GetPart();
            if (part != null)
            {
                if(part.GetType() == typeof(T) || typeof(T) == typeof(Part))
                {
                    childs.Add(part);
                }
            }
        });

        return childs;
    }


    // returns all the childs (recursive) of this Part which type match T
    public List<Part> GetChildsRecursively<T>()
    {
        List<Part> childs = new List<Part>();

        m_slots.ForEach(slot =>
        {
            Part part = slot.GetPart();

            if (part != null)
            {
                if (part.GetType() == typeof(T))
                {
                    childs.Add(part);
                }
                else
                {
                    childs.AddRange(part.GetChildsRecursively<T>());
                }

            }
        });

        return childs;
    }

    // Returns all the MeshFilters linked to the Part (Stops at Turrets)
    public List<MeshFilter> GetLinkedMeshes_Recursive()
    {
        List<MeshFilter> linkedMeshes = new List<MeshFilter>();

        // Add Mesh of current part to List
        linkedMeshes.Add(GetComponent<MeshFilter>());

        // Recursively Add Mesh of childs to List
        GetChilds<Part>().ForEach(part =>
        {
            if (part.m_type != PartType.Turret)
            {
                linkedMeshes.AddRange(part.GetLinkedMeshes_Recursive());
            }
        });

        return linkedMeshes;
    }

    public string ToJSon()
    {
        string jsonString = "{" + "\n";

        jsonString += "Mesh:" + m_mesh.name + "," +"\n";
        jsonString += "Material:" + m_material.name + "," +"\n";
        jsonString += "Type:" + m_type + "," + "\n";
        jsonString += "Size:" + m_size + "," + "\n";
        jsonString += "Slots:[" + "\n";

        m_slots.ForEach(x => {jsonString += x.ToJSon() + "," + "\n"; });

        // Remove last coma
        jsonString.Remove(jsonString.Length - 1);

        jsonString += "]}"  + "\n";

        return jsonString;
    }
    
}