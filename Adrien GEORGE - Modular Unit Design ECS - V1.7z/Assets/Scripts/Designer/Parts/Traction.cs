﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Traction : Part
{
    public float m_maxSpeed;
    public float m_maxSlope;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
