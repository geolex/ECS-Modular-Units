﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : Part
{
    public float m_fireRate;
    public float m_penetration;
    public float m_damage;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
