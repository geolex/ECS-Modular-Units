﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using Unity.Entities;
using Unity.Rendering;
using Unity.Transforms;
using System.IO;
using UnityEditor;

public class DesignerScript : MonoBehaviour
{
    [SerializeField] private GameObject m_hullPrefab;

    [SerializeField] private Slot m_selectedSlot;           // Currently active Slot
    [SerializeField] private GameObject m_hull;             // Root of the designer

    private RaycastHit m_raycastHit;

    [SerializeField] private List<Part> m_parts;

    EntityArchetype customUnit;

    [Header("UI Handler")]
    [SerializeField] Designer_UI m_UIHandler;



    


    // Start is called before the first frame update
    void Start()
    {

        // Should be created when Unit is read from JSon
        //customUnit = World.Active.EntityManager.CreateArchetype(typeof(LocalToWorld), typeof(Translation), typeof(RenderMesh), typeof(VelocityComponent), typeof(ArmorComponent));

        m_hull = Instantiate(m_hullPrefab, Vector3.zero, Quaternion.identity);

        if (m_UIHandler)
        {
            m_UIHandler.m_designerScript = this;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out m_raycastHit);

            if (m_raycastHit.collider != null)
            {
                if (m_raycastHit.collider.tag == "slotTag")
                {
                    m_selectedSlot = m_raycastHit.collider.gameObject.GetComponent<Slot>();

                    List<Part> compatibleParts = GetCompatibleParts(m_selectedSlot.m_type, m_selectedSlot.m_size);

                    if (m_UIHandler)
                    {
                        m_UIHandler.SetList(compatibleParts);
                    }
                    
                }
                else
                {
                    Debug.Log(m_raycastHit.collider.name);
                }
            }
        }
    }

    #region PART LIST ACCESSORS
    private List<Part> GetCompatibleParts(PartType _type, PartSize _size)
    {
        List<Part> compatibleParts = new List<Part>();

        m_parts.ForEach(part => { if (part.m_type == _type && part.m_size == _size) compatibleParts.Add(part); });

        return compatibleParts;
    }

    private void PrintAllCompatibleParts(PartType _type, PartSize _size)
    {
        GetCompatibleParts(_type, _size).ForEach(part => { Debug.Log(part.name); });
    }
    #endregion

    public void AddComponent(Part _part)
    {
        m_selectedSlot.SetPart(_part);
    }




    public void BakeUnit(string _name)
    {
        string newUnitPath = Application.dataPath + "/Units/Custom/" + _name + ".json";

        if (!File.Exists(newUnitPath))
        {
            StreamWriter fileOutput = new StreamWriter(newUnitPath);

            fileOutput.Write(UnitToJSon(_name));

            MergeMeshes_Recursive(m_hull.GetComponent<Part>(), _name);
            //MergeData_Recursive(m_hull.GetComponent<Part>(), fileOutput, _name) ;

            fileOutput.Close();
        }
    }




    private void MergeData_Recursive(Part _base, StreamWriter _output, string _name, int _index = 0)
    {
        #region Components

        _output.WriteLine(_name + "_" + _base.name + "_" + _index + "{");

        List<Part> tractions = _base.GetChildsRecursively<Traction>();
        List<Part> armors = _base.GetChildsRecursively<Armor>();
        List<Part> weapons = _base.GetChildsRecursively<Weapon>();

        // TRACTION
        float maxSpeed = 0f;
        float maxSlope = 0f;
        tractions.ForEach(traction => 
        {
            maxSpeed = Mathf.Min(maxSpeed, ((Traction)traction).m_maxSpeed);
            maxSlope = Mathf.Min(maxSlope, ((Traction)traction).m_maxSlope);
        });

        _output.WriteLine("Velocity{ maxSpeed = " + maxSpeed + " }");
        _output.WriteLine("Navigation{ maxSlope = " + maxSlope + " }");

        
        // ARMOR
        int totalArmor = 0;
        int totalLife = 0;
        armors.ForEach(armor =>
        {
            totalArmor += ((Armor)armor).m_armor;
            totalLife += ((Armor)armor).m_life;
        });

        _output.WriteLine("Resistance{ armor = " + totalArmor + ", life = " + totalLife + " }");
        #endregion

        #region subEntities
        _output.WriteLine("Childs{");


        List<Part> turrets = _base.GetChildsRecursively<Turret>();

        turrets.ForEach(turret =>
        {
            MergeData_Recursive(turret, _output, _name, (_index * 10) + 1);
        });
        
        _output.WriteLine("}");
        #endregion

        _output.WriteLine("}");
    }










    public string UnitToJSon(string _name)
    {
        string jsonValue = "";

        jsonValue += m_hull.GetComponent<Part>().ToJSon();

        return jsonValue;
    }

    public void JSonToUnit(string _json)
    {

    }





    #region MESH TOOLS
    private void MergeMeshes_Recursive(Part _base, string _name, int _index = 0) { 
        List<MeshFilter> linkedMeshes = new List<MeshFilter>();
        Mesh resultMesh = new Mesh();

        // Add mesh of _base model
        linkedMeshes.Add(_base.GetComponent<MeshFilter>());

        // Add meshes of all independent (!= turret) parts recursively
        _base.GetChilds<Part>().ForEach(part =>
        {
            if (part.m_type == PartType.Turret)
            {
                MergeMeshes_Recursive(part, _name, (_index * 10) + 1);
            }
            else
            {
                linkedMeshes.AddRange(part.GetLinkedMeshes_Recursive());
            }
        });

        CombineInstance[] combineInstances = new CombineInstance[linkedMeshes.Count];

        for(int i=0; i < combineInstances.Length; i++)
        {
            combineInstances[i].mesh = linkedMeshes[i].sharedMesh;
            combineInstances[i].transform = linkedMeshes[i].transform.localToWorldMatrix;
        }

        resultMesh.CombineMeshes(combineInstances);

        AssetDatabase.CreateAsset(resultMesh, "Assets/Meshes/Procedural/" + _name + "_" + _base.name + "_" + _index + ".asset");
        AssetDatabase.SaveAssets();
    }
    #endregion
}
